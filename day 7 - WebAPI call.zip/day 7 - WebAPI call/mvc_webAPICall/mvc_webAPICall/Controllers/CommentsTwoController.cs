﻿using Microsoft.AspNetCore.Mvc;
using mvc_webAPICall.Models;
namespace mvc_webAPICall.Controllers
{
    public class CommentsTwoController : Controller
    {


        CommentsModel model = new CommentsModel();

        public IActionResult Comments()
        {
            ViewBag.comments = model.GetComments();
            return View();
        }
    }
}
