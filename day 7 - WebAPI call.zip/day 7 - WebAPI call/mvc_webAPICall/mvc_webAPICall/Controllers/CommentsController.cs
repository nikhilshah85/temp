﻿using Microsoft.AspNetCore.Mvc;

namespace mvc_webAPICall.Controllers
{
    public class CommentsController : Controller
    {
        public IActionResult Comments()
        {
            return View();
        }
    }
}
