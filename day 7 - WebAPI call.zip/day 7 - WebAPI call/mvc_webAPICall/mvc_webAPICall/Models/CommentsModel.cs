﻿//using Microsoft.AspNet.WebApi.Client;
namespace mvc_webAPICall.Models
{
    public class CommentsModel
    {
        public int postId { get; set; }
        public int id { get; set; }
        public string name { get; set; }
        public string email { get; set; }
        public string body { get; set; }

        List<CommentsModel> data = new List<CommentsModel>();

        public List<CommentsModel> GetComments()
        {
            string url = "https://jsonplaceholder.typicode.com/comments";
            HttpClient client = new HttpClient();

            client.DefaultRequestHeaders.Accept.Clear(); //clear the defaults from browser
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));

            var call = client.GetAsync(url);

            var response = call.Result;

            if (response.IsSuccessStatusCode)
            {
                var read = response.Content.ReadAsAsync<List<CommentsModel>>();
                read.Wait();
                data = read.Result;
            }
            return data;
        }
    }
}
