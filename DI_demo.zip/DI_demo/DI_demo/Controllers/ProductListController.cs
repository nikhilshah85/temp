﻿using Microsoft.AspNetCore.Mvc;
using DI_demo.Models;
namespace DI_demo.Controllers
{
    public class ProductListController : Controller
    {
        Products pObj; // so you are crateing this obj, and you are responsible to destroy it

        public ProductListController(Products _pObj) //framework will create the object and inject it here
        {
            pObj = _pObj;
        }
        public IActionResult ShowProducts()
        {

            return View(pObj.GetProductsList());
        }
    }
}
