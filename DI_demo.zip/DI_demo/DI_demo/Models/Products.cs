﻿namespace DI_demo.Models
{
    public class Products
    {
        public int pId { get; set; }
        public string pName { get; set; }
        public double pPrice { get; set; }
        public bool pIsInstock { get; set; }


        static List<Products> pList = new List<Products>()
        {
            new Products(){ pId=101, pName="Pepsi", pIsInstock=true,pPrice=50 },
            new Products(){ pId=102, pName="Pepsi", pIsInstock=true,pPrice=50 },
            new Products(){ pId=103, pName="Pepsi", pIsInstock=true,pPrice=50 },
            new Products(){ pId=104, pName="Pepsi", pIsInstock=true,pPrice=50 }
        };


        public List<Products> GetProductsList()
        {
            return pList;
        }

        public List<Products> AddProduct(Products newProd)
        {
            pList.Add(newProd);
            return pList;
        }


    }
}
