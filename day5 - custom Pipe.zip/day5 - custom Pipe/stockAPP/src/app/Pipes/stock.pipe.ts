import { Pipe, PipeTransform } from "@angular/core";


@Pipe({name:'stockstatus'})
export class Stockstatus implements PipeTransform{

    transform(value:any,purchase:number,current:number):string {

        if(purchase < current)
        {
            return 'Profit';
        }
        else{
            return 'Loss';
        }
    }


}