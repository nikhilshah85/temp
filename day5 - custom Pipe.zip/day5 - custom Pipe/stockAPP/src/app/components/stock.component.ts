import { Component } from "@angular/core";



@Component({
    selector:'stockdetails',
    templateUrl:'stock.component.html',
    styleUrls:['stock.component.css']
})
export class Stock 
{
    stockPortfolio = [
        {stockId:101,stockName:'RIL',stockQty:100, purchasePrice:2000,currentPrice:2500,stockCategoty:'Petro Chem'},
        {stockId:102,stockName:'Tata',stockQty:100, purchasePrice:5,currentPrice:6,stockCategoty:'Petro Chem'},
        {stockId:103,stockName:'Maruti',stockQty:100, purchasePrice:8,currentPrice:5,stockCategoty:'Petro Chem'},
        {stockId:104,stockName:'Honda',stockQty:100, purchasePrice:25,currentPrice:60,stockCategoty:'Petro Chem'},
        {stockId:105,stockName:'Nestle',stockQty:100, purchasePrice:80,currentPrice:40,stockCategoty:'Petro Chem'},
        {stockId:106,stockName:'HUL',stockQty:100, purchasePrice:2,currentPrice:3,stockCategoty:'Petro Chem'},
        {stockId:107,stockName:'Reebok',stockQty:100, purchasePrice:5,currentPrice:12,stockCategoty:'Petro Chem'},
        {stockId:108,stockName:'Amazon',stockQty:100, purchasePrice:60,currentPrice:55,stockCategoty:'Petro Chem'},
        {stockId:109,stockName:'Facebook',stockQty:100, purchasePrice:200,currentPrice:180,stockCategoty:'Petro Chem'},
        {stockId:110,stockName:'Infosys',stockQty:100, purchasePrice:1,currentPrice:6,stockCategoty:'Petro Chem'},
    ]

    totalInvestmentValue():number
    {
        let totalInvestment:number = 0;
        for (let index = 0; index < this.stockPortfolio.length; index++) {
            
            totalInvestment = totalInvestment + this.stockPortfolio[index].stockQty * this.stockPortfolio[index].purchasePrice;
        }
        return totalInvestment;
    }

    portfolioValue():number
    {
        let portfolioValue:number = 0;
        for (let index = 0; index < this.stockPortfolio.length; index++) {
            
            portfolioValue = portfolioValue + this.stockPortfolio[index].stockQty * this.stockPortfolio[index].currentPrice;
        }
        return portfolioValue;
    }
}

export default Stock;
