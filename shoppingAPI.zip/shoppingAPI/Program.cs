var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddCors( policy =>{
    policy.AddDefaultPolicy(defaultPolicy =>{
        defaultPolicy.AllowAnyHeader().AllowAnyMethod().AllowAnyOrigin();
    });

    policy.AddPolicy("clientA", policy =>{
        
        string[] methodsAlloed = new string[2];
        methodsAlloed[0] ="GET";
        methodsAlloed[1] = "POST";

        string[] originsAllowed = new string[1];
        originsAllowed[0] = "www.google.com";
        policy.AllowAnyHeader().WithMethods(methodsAlloed).WithOrigins(originsAllowed);
    });
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors();
app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
