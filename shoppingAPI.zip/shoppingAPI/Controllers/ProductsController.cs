using Microsoft.AspNetCore.Mvc;
using shoppingAPI.Models;
namespace shoppingAPI.Controllers;

[ApiController]
[Route("[controller]")]
public class ProductsController : ControllerBase
{
  
  Products pObj = new Products();  //this is a big crime, you not should not create a new object, if you do not intend to clear ir
                                    //write dispose method
                                    //Dont worry, use DI

[HttpGet]
[Route("plist")]
    public IActionResult GetProducts()
    {
        return Ok(pObj.GetAllProducts());
    }        

[HttpGet]
[Route("plist/{id}")]
    public IActionResult GetProductById(int id)
    {
        return Ok(pObj.GetProductById(id));
    }              

[HttpPost]
[Route("plist/add")]
    public IActionResult AddProduct(Products newObj)
    {
        return Created("",pObj.AddProduct(newObj));
    }    

}
