

namespace shoppingAPI.Models;
public class Products
{
    #region Properties


    public int pId   { get; set; }
    public string pName { get; set; }
    public string pCategory { get; set; }
    public double pPrice { get; set; }

    public bool pIsInStock { get; set; }
#endregion

    static List<Products> pList = new List<Products>()
    {
        new Products(){ pId=101, pName="Pepsi", pCategory="Cold-Drink", pPrice=1, pIsInStock=true },
        new Products(){ pId=102, pName="IPhone", pCategory="Electronics", pPrice=1400, pIsInStock=false },
        new Products(){ pId=103, pName="Nike", pCategory="Footware", pPrice=800, pIsInStock=true },
        new Products(){ pId=104, pName="Air Pods", pCategory="Electronics", pPrice=750, pIsInStock=true },
        new Products(){ pId=105, pName="Tesla", pCategory="Car", pPrice=200000, pIsInStock=false },
    };

    public List<Products> GetAllProducts()
    {
        return pList;
    }

    public Products GetProductById(int id)
    {
        var pr = (from p in pList
        where p.pId == id
        select p).Single();
        return pr;
    }


    public string AddProduct(Products newObj)
    {
    pList.Add(newObj);
    return "Product Added ";
    }
}