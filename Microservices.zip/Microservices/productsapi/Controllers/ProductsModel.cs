using Microsoft.AspNetCore.Mvc;

namespace productsapi.Controllers;

public class ProductsModel
{  

    public int pId{get;set;}    
    public string pName { get; set; }
    public double pPrice { get; set; }
    public bool pIdInStock { get; set; }
    public string pCategory { get; set; }


    static List<ProductsModel> pList = new List<ProductsModel>()
    {
        new ProductsModel(){ pId=101, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=102, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=103, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=104, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=105, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=106, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
        new ProductsModel(){ pId=107, pName="Pepsi", pCategory="ColdDrink", pPrice=50, pIdInStock=true},
    };

    public List<ProductsModel> ProductList()
    {
        return pList;
    }

}








