using Microsoft.AspNetCore.Mvc;

namespace productsapi.Controllers;



[ApiController]
[Route("[controller]")]
public class ProductsController : ControllerBase
{

[HttpGet]
[Route("products")]
    public IActionResult GetProducts()
    {
        ProductsModel pObj = new ProductsModel();
        return Ok(pObj.ProductList());
    }
}
