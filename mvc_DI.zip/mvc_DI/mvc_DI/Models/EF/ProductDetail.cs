﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
namespace mvc_DI.Models.EF
{
    public partial class ProductDetail
    {


        public int PId { get; set; }
        [Display(Name ="Product")]
        public string PName { get; set; } = null!;

        [StringLength(20,MinimumLength =4,ErrorMessage ="Product Name should be between 4 and 20 characters only")]
        public string PCategory { get; set; } = null!;


        
        [Display(Name ="Offer Price")]
        [System.ComponentModel.DataAnnotations.Range(500,2500,ErrorMessage ="Please enter Price between 500 and 2500 Only")]
        public int PPrice { get; set; }
        public bool PIsInStock { get; set; }
    }
}
