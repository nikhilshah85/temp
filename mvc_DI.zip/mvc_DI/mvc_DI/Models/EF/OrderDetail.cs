﻿using System;
using System.Collections.Generic;

namespace mvc_DI.Models.EF
{
    public partial class OrderDetail
    {
        public int OrderId { get; set; }
        public DateTime OrderData { get; set; }
        public int OrderQty { get; set; }
        public int OrderPrice { get; set; }
        public int PId { get; set; }
        public int CId { get; set; }
    }
}
