﻿using System;
using System.Collections.Generic;

namespace mvc_DI.Models.EF
{
    public partial class CustomerDetail
    {
        public int Id { get; set; }
        public string CustomerName { get; set; } = null!;
        public string CustomerType { get; set; } = null!;
        public bool CustomerIsActive { get; set; }
        public int CustomerWalletBalance { get; set; }
    }
}
