﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace mvc_DI.Models.EF
{
    public partial class shoppingAPPContext : DbContext
    {
        public shoppingAPPContext()
        {
        }

        public shoppingAPPContext(DbContextOptions<shoppingAPPContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CustomerDetail> CustomerDetails { get; set; } = null!;
        public virtual DbSet<OrderDetail> OrderDetails { get; set; } = null!;
        public virtual DbSet<ProductDetail> ProductDetails { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("server=WIN8\\NIKHILINSTANCE;database=shoppingAPP;integrated security=true");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CustomerDetail>(entity =>
            {
                entity.Property(e => e.CustomerIsActive).HasColumnName("customerIsActive");

                entity.Property(e => e.CustomerName).HasColumnName("customerName");

                entity.Property(e => e.CustomerType).HasColumnName("customerType");

                entity.Property(e => e.CustomerWalletBalance).HasColumnName("customerWalletBalance");
            });

            modelBuilder.Entity<OrderDetail>(entity =>
            {
                entity.HasKey(e => e.OrderId);

                entity.Property(e => e.OrderId).HasColumnName("orderId");

                entity.Property(e => e.CId).HasColumnName("cId");

                entity.Property(e => e.OrderData).HasColumnName("orderData");

                entity.Property(e => e.OrderPrice).HasColumnName("orderPrice");

                entity.Property(e => e.OrderQty).HasColumnName("orderQty");

                entity.Property(e => e.PId).HasColumnName("pId");
            });

            modelBuilder.Entity<ProductDetail>(entity =>
            {
                entity.HasKey(e => e.PId);

                entity.Property(e => e.PId).HasColumnName("pId");

                entity.Property(e => e.PCategory).HasColumnName("pCategory");

                entity.Property(e => e.PIsInStock).HasColumnName("pIsInStock");

                entity.Property(e => e.PName).HasColumnName("pName");

                entity.Property(e => e.PPrice).HasColumnName("pPrice");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
