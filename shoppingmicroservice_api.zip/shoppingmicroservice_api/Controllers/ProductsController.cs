using Microsoft.AspNetCore.Mvc;
using shoppingmicroservice_api.Models.EF;
namespace shoppingmicroservice_api.Controllers;

[ApiController]
[Route("[controller]")]
public class ProductsController : ControllerBase
{

    ShoppingDbContext _db;
    public ProductsController(ShoppingDbContext _dbRef)
    {
        _db = _dbRef;
    }

    [HttpGet]
    [Route("plist")]
    public IActionResult GetAllProducts()
    {
        return Ok(_db.Products.ToList());
    }

 [HttpGet]
    [Route("plist/{id}")]
    public IActionResult GetProductById(int id)
    {
        var p = (from pr in _db.Products
        where pr.PId == id
        select pr).Single();

        if(p != null){
            return Ok(p);
        }
        return NotFound("Product with Id " + id + " Not found in system");
    }
    

    [HttpPost]
    [Route("plist/add")]
    public IActionResult AddProduct([FromBody]Product newObj)
    {
        _db.Products.Add(newObj);
        _db.SaveChanges();
        return Created("","Product Added Successfully to database");
    }

[HttpDelete]
[Route("plist/delete/{id}")]
    public IActionResult DeleteProduct(int id)
    {
         var p = (from pr in _db.Products
        where pr.PId == id
        select pr).Single();
        if(p!=null)
        {
            _db.Products.Remove(p);
            _db.SaveChanges();
            return Accepted("Product deleted from System");
        }
        return NotFound("Product not found in system");

        

    }

[HttpPut]
[Route("plist/edit")]
public IActionResult UpdateProduct([FromBody] Product updates)
{
      var p = (from pr in _db.Products
        where pr.PId == updates.PId
        select pr).Single();
        if(p!=null)
        {
           p.PName = updates.PName;
           p.PCategory = updates.PCategory;
           p.PPrice = updates.PPrice;
            _db.SaveChanges();
            return Accepted("Product updated Successfully");
        }
        return NotFound("Product not found in system");
}

}
