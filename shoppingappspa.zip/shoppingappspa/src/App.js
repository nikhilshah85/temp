import logo from './logo.svg';
import './App.css';
import Home from './Components/Home/Home';
import About from './Components/About/About';
import Contact from './Components/Contact/Contact';
import News from './Components/News/News';
import Products from './Components/Products/Products';
import { Routes,Route } from 'react-router-dom';
import Navigation from './Components/Navigation/Navigation';

function App() {
  return (
    <div className="App">
   
   {/* //old way */}
{/* 
    <Home></Home>

    <hr/>

    <About></About>

    <hr/>

    <Contact></Contact>

    <hr/>

    <News></News>

    <hr/>

    <Products></Products> */}

    <h1> Welcome to React SPA Application </h1>

<Navigation></Navigation>
 
    <Routes>
      <Route path='home' element={<Home></Home>}/>
      <Route path='about' element={<About></About>}/>
      <Route path='contact' element={<Contact></Contact>}/>
      <Route path='news' element={<News></News>}/>
      <Route path='products' element={<Products></Products>}/>
    </Routes>


<p> Copyright at  trainings.com 2015-2025</p>
    </div>
  );
}

export default App;



























