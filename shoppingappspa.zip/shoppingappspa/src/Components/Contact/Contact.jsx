import { Component } from "react";

class Contact extends Component
{

render(){
    return(<div className="contactDiv">

        <h1> Welcome to contact us </h1>

        <h4> Emails : someone@gmail.com </h4>
        <h4> Phone : 132156151 </h4>
        <h4> Customer Care : 1564654315413534 </h4>
    </div>)
}

}

export default Contact;