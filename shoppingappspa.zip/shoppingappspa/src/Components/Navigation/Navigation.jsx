import { Component } from "react";
import { Link } from 'react-router-dom'
class Navigation extends Component
{

    render(){
        return(<div>
           
           <table border="1">
            <tr>
                <td>  <Link to='/home'>Home</Link>  </td>
                <td>  <Link to='/about'>About Us </Link>  </td>
                <td>  <Link to='/contact'>Contact Us</Link>  </td>
                <td>  <Link to='/news'>Latest News</Link>  </td>
                <td>  <Link to='/products'>Products List</Link>  </td>
            </tr>

           </table>


        </div>)
    }

}

export default Navigation;