import { Component } from "react";

class About extends Component
{

        render(){
            return(<div className='aboutDiv'>
                <h1> Welcome to About us page</h1>

<h4>
                About Global Reach
A History of Web Innovation
Global Reach was founded in 1995 and since then, it has become a leader in content management solutions, custom web development, and a trusted digital marketing agency. We are proud of our Iowa roots and our history of award-winning innovation. 
          
Our Staff
We are a team of highly qualified professionals with decades of experience in the latest technologies. Innovation, collaboration, and pride in our work motivate us to pull out all the stops when it comes to meeting your goals.

We are always looking for talented team players. See our current career openings.

Connect with us on LinkedIn. 

Our Mission
Our mission is to dedicate ourselves to outstanding web development that empowers our clients to excel in their markets, make meaningful connections with their audiences, and improve their productivity.

Our Process
Delve deeper into our proven methodology and company philosophy born from our years of experience. Our process »

Our Offices
Ames
ISU Research Park
2321 North Loop Drive
Suite 210
Ames, Iowa 50010
          
</h4>
          
          
          
            </div>)
        }

}

export default About;