import { Component } from 'react';


class Home extends Component
{

render(){
    return(<div className='homeDiv'>


        <p>
            
HOME / MEDIA HUB / BLOG / 8 KEY FEATURES YOUR HOMEPAGE SHOULD INCLUDE
8 Key Features Your Homepage Should Include
Animation of computer screen
Posted on 09/27/2017 at 11:40 AM

Your homepage is an essential tool for your business and often serves as the first impression to potential customers. There are many important components of effective web design, like white space, font selection, color schemes, and layout, but the core of a website is its content, not its design. Within a matter of seconds, your homepage needs to introduce your product or service and entice visitors to explore your site further.

TL;DR: Click any of the buttons below to jump ahead or keep scrolling to learn more.

<h1>
1. LOGO  2. NAVIGATION  3. HEADLINE  4. CTA  

5. SOCIAL PROOF 6. PHOTOS 7. TEXT CONTENT 8. FOOTER
</h1>

Straightforward and intuitive navigation is another vital feature your website should include in the header. If your website is content-heavy, a search box might be a valuable asset to include here. The navigation menu should be easy to locate with items that make sense to new visitors. The navigation area is like a road map--it’s necessary to give visitors an overview of the content, as well as help them to locate the information they are looking for using the most efficient route. Descriptive and thorough navigation is also beneficial in reducing bounce rates.

The goal of your website’s homepage is to pique the interest of visitors and prompt them to delve deeper into the pages of your website. A call to action (CTA) is one way to pull people into the interior pages, begin the selling cycle, or at least initiate direct contact. CTA areas or buttons can be linked to contact forms, subscription enrollment forms, or other pages within your website that provide more information. The easier and more intriguing you make it for the visitor to click this CTA, the better the chance they will invest time in browsing your website.
BONUS FEATURE

 "I NEED HELP!"

Keep reading to find out what 8 content features are vital to a successful homepage.

1. Logo
Your logo should be visible at the top of your website. It’s the core of your business’ branding and identity, after all. The logo is a tangible representation that encompasses your products or services and is a key piece for clients to recognize and connect with your brand. The logo on a website often doubles in functionality as a link to the homepage, so you want it to be in an obvious location within the header.
        </p>
    </div>)
}


}

export default Home;