
import "../../App.css"
import { Component } from "react";
class Products extends Component {
  commentsData = [];
  GetCommentsData() {
    fetch("https://jsonplaceholder.typicode.com/comments")
      .then((response) => response.json())
      .then((data) => {
        //code to display the data goes here
        //code to addign the data to variable goes here,
        // variable will then use map to display data
        //give the data to a state variable
        console.log(data);
      })
      .catch((err) => {
        alert("Got Errorrrrrrrr");
      })
      .finally(() => {
        alert("Call completed");
      });
  }
  render() {
    return (
      <div className="productsDiv">
        <button onClick={this.GetCommentsData}>Get Comments </button>
      </div>
    );
  }
}
export default Products;
