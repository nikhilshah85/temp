import { Component } from "react";

class News extends Component
{

render(){
    return(<div className="newsDiv">

        <h1>Breaking News  </h1>
        <h3>
        For journalists, members of the international media and the public. Stay up-to-date on UN Women news announcements, press releases and media advisories. Explore Events. Browse Resources. Donate Online.
News
UN Women's latest content Statements, stories and more
Media compact
Advancing women's empowerment. With and through the media.
        </h3>

      
    </div>)
}

}

export default News;